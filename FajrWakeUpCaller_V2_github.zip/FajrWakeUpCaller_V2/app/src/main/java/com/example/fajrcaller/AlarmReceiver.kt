package com.example.fajrcaller

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    companion object { const val MAX_LATE_MS = 30 * 60 * 1000L }

    override fun onReceive(ctx: Context, intent: Intent) {
        val scheduledAt = Prefs.scheduledAt(ctx)      // read BEFORE re-arming overwrites it
        Scheduler.schedule(ctx)                       // arm tomorrow first so one failure never ends the chain
        val db = Db(ctx)
        if (scheduledAt > 0 && System.currentTimeMillis() - scheduledAt > MAX_LATE_MS) {
            db.log("All", "-", St.SKIPPED_TOO_LATE, "Alarm fired more than 30 min late; calls skipped")
            return
        }
        try {
            ctx.startForegroundService(Intent(ctx, CallService::class.java))
        } catch (e: Exception) {
            db.log("-", "-", St.FAILED_SERVICE, "Could not start call service: ${e.javaClass.simpleName}")
        }
    }
}
