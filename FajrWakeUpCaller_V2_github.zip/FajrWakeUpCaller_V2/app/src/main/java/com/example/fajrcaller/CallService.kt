package com.example.fajrcaller

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.CallLog
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.ServiceState
import android.telephony.TelephonyManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Runs ONE call sequence at a time. Further start requests while it runs are logged and ignored; they
 * never stop the running sequence. Contacts are dialed strictly one by one: the next number is dialed
 * only after the phone's call state is back to IDLE.
 *
 * The app NEVER disconnects a call. Android gives a normal (non-default-dialer) app no supported way to
 * tell "still ringing" from "answered" while the call is live, so it cannot safely hang up.
 */
@Suppress("DEPRECATION")
class CallService : Service() {
    companion object {
        const val CH = "fajr_calls"
        /** Safety cap for one call. If a call is still active after this, the rest of the sequence is aborted. */
        const val HARD_CAP_MS = 20 * 60 * 1000L
        private val lock = Any()
        private var running = false
        private var lastStartId = 0
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val number = intent?.getStringExtra("number")
        val name = intent?.getStringExtra("name") ?: "Test"
        // Every startForegroundService() must be answered with startForeground(); repeating it is harmless.
        val fgOk = enterForeground()
        var startWorker = false
        synchronized(lock) {
            lastStartId = startId
            if (fgOk && !running) { running = true; startWorker = true }
        }
        if (!fgOk) {
            Db(this).log("-", "-", St.FAILED_SERVICE, "Android refused to start the foreground service")
            stopIfIdle(); return START_NOT_STICKY
        }
        if (!startWorker) {
            Db(this).log(if (number != null) name else "All", number ?: "-", St.SKIPPED_BUSY,
                "A call sequence is already running; this request was ignored")
            return START_NOT_STICKY            // deliberately no stopSelf: the running sequence owns shutdown
        }
        Thread {
            try { work(number, name) }
            catch (e: Exception) { Db(this).log("-", "-", St.ERROR, e.toString()) }
            finally { finish() }
        }.start()
        return START_NOT_STICKY
    }

    private fun enterForeground(): Boolean = try {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Wake-up calls", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_call)
            .setContentTitle("Fajr Wake-Up Caller")
            .setContentText("Placing wake-up calls one by one...")
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        true
    } catch (e: Exception) { false }

    /** Called only by the worker that owns the run. stopSelf(id) is ignored by Android if a newer start arrived. */
    private fun finish() {
        synchronized(lock) {
            running = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(lastStartId)
        }
    }

    private fun stopIfIdle() { synchronized(lock) { if (!running) stopSelf(lastStartId) } }

    // ------------------------------------------------------------------ sequence

    private fun work(testNumber: String?, testName: String) {
        val db = Db(this)
        val targets: List<Contact>
        if (testNumber != null) {
            targets = listOf(Contact(0, testName, testNumber, true))     // manual test bypasses the daily guard
        } else {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            if (Prefs.lastRun(this) == today) { db.log("All", "-", St.SKIPPED_DUPLICATE, "Daily calls already ran today"); return }
            Prefs.setLastRun(this, today)
            targets = db.contacts().filter { it.enabled }
        }
        if (targets.isEmpty()) { db.log("-", "-", St.NO_CONTACTS, "No enabled contacts"); return }
        for ((i, c) in targets.withIndex()) {
            if (c.id != 0L && !db.isEnabled(c.id)) { db.log(c.name, c.number, St.SKIPPED_DISABLED, "Disabled before its turn"); continue }
            if (!callOne(c, db)) {
                targets.drop(i + 1).forEach { db.log(it.name, it.number, St.ABORTED_CALL_ACTIVE, "Not called: previous call never ended") }
                return
            }
            Thread.sleep(3000)
        }
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun sleep(ms: Long) = Thread.sleep(ms)

    private fun hasNetwork(tm: TelephonyManager): Boolean {
        try { tm.serviceState?.let { return it.state == ServiceState.STATE_IN_SERVICE } } catch (_: Exception) { }
        return tm.networkOperator.isNotEmpty()      // empty string = not registered on any network
    }

    private fun waitIdle(tm: TelephonyManager, ms: Long): Boolean {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            if (tm.callState == TelephonyManager.CALL_STATE_IDLE) return true
            sleep(500)
        }
        return tm.callState == TelephonyManager.CALL_STATE_IDLE
    }

    /** @return false only if the sequence must stop (a call would not end). */
    private fun callOne(c: Contact, db: Db): Boolean {
        if (!has(Manifest.permission.CALL_PHONE) || !has(Manifest.permission.READ_PHONE_STATE)) {
            db.log(c.name, c.number, St.FAILED_PERMISSION, "Phone permission missing (CALL_PHONE and READ_PHONE_STATE are required)")
            return true
        }
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        if (tm.simState != TelephonyManager.SIM_STATE_READY) {
            db.log(c.name, c.number, St.FAILED_NO_SIM, "SIM not ready (state ${tm.simState})"); return true
        }
        if (Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1) {
            db.log(c.name, c.number, St.FAILED_NO_NETWORK, "Airplane mode is on"); return true
        }
        if (!hasNetwork(tm)) { db.log(c.name, c.number, St.FAILED_NO_NETWORK, "No cellular service"); return true }

        // Strictly one by one: the line must be idle before dialing.
        try {
            if (!waitIdle(tm, 30_000)) { db.log(c.name, c.number, St.SKIPPED_PHONE_BUSY, "Phone is already in another call"); return true }
        } catch (e: SecurityException) { db.log(c.name, c.number, St.FAILED_PERMISSION, "Cannot read call state"); return true }

        val dialAt = System.currentTimeMillis()
        val tel = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        try {
            tel.placeCall(Uri.fromParts("tel", c.number, null), Bundle())
        } catch (e: SecurityException) { db.log(c.name, c.number, St.FAILED_PERMISSION, e.message ?: "Dial not permitted"); return true }
        catch (e: Exception) { db.log(c.name, c.number, St.FAILED_CALL, "Dial error: ${e.javaClass.simpleName}"); return true }

        // Wait for the call to leave IDLE.
        var started = false
        while (System.currentTimeMillis() - dialAt < 20_000) {
            if (tm.callState != TelephonyManager.CALL_STATE_IDLE) { started = true; break }
            sleep(250)
        }
        if (!started) { db.log(c.name, c.number, St.FAILED_CALL, "Call never started (dialer or carrier rejected it)"); return true }

        // Wait for the call to end. No disconnecting, ever.
        val ringMs = Prefs.ringSeconds(this) * 1000L
        var limitExceeded = false
        while (tm.callState != TelephonyManager.CALL_STATE_IDLE) {
            val el = System.currentTimeMillis() - dialAt
            if (el > ringMs) limitExceeded = true
            if (el > HARD_CAP_MS) {
                db.log(c.name, c.number, St.ABORTED_CALL_ACTIVE, "Call still active after ${HARD_CAP_MS / 60000} min; stopping the sequence")
                return false
            }
            sleep(500)
        }
        val secs = (System.currentTimeMillis() - dialAt) / 1000
        sleep(2500)                                   // let the system write the call-log entry
        val answered = answeredFromCallLog(c.number, dialAt)
        val limitNote = if (limitExceeded) "; ring limit (${Prefs.ringSeconds(this)}s) exceeded, call not disconnected" else ""
        when {
            answered == true -> db.log(c.name, c.number, St.ANSWERED, "Total ${secs}s (from call log)$limitNote")
            secs < 4 -> db.log(c.name, c.number, St.FAILED_CALL, "Call ended after ${secs}s: busy, rejected or network error")
            answered == false -> db.log(c.name, c.number, St.NO_ANSWER, "Ended after ${secs}s, not answered (from call log)$limitNote")
            else -> db.log(c.name, c.number, St.CALL_ENDED, "Ended after ${secs}s; answered or not is unknown (allow call-log access to see it)$limitNote")
        }
        return true
    }

    /** Best effort. Some phone makers record duration differently, so treat it as a hint. */
    private fun answeredFromCallLog(number: String, sinceMs: Long): Boolean? {
        if (!has(Manifest.permission.READ_CALL_LOG)) return null
        try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.DURATION),
                "${CallLog.Calls.DATE}>=? AND ${CallLog.Calls.TYPE}=?",
                arrayOf((sinceMs - 5000).toString(), CallLog.Calls.OUTGOING_TYPE.toString()),
                "${CallLog.Calls.DATE} DESC"
            )?.use { cur ->
                while (cur.moveToNext()) {
                    if (sameNumber(cur.getString(0), number)) return cur.getLong(1) > 0
                }
            }
        } catch (_: Exception) { }
        return null
    }

    private fun sameNumber(a: String?, b: String): Boolean {
        val x = (a ?: "").filter { it.isDigit() }
        val y = b.filter { it.isDigit() }
        return x.length >= 7 && y.length >= 7 && x.takeLast(9) == y.takeLast(9)
    }
}
