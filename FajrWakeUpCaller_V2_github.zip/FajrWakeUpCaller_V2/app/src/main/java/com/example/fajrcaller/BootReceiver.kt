package com.example.fajrcaller

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Re-arms the alarm after reboot, app update, clock/timezone change, or exact-alarm access changes. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (Scheduler.schedule(ctx) == Scheduler.Result.NEEDS_EXACT_PERMISSION) {
            Db(ctx).log("-", "-", St.ALARM_NOT_SCHEDULED, "Exact alarm access is off; daily call is NOT scheduled")
        }
    }
}
