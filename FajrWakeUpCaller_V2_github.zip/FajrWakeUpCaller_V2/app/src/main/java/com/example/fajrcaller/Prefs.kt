package com.example.fajrcaller

import android.content.Context

object Prefs {
    const val RING_MIN = 15
    const val RING_MAX = 120
    private fun p(c: Context) = c.getSharedPreferences("fajr", Context.MODE_PRIVATE)
    fun hour(c: Context) = p(c).getInt("hour", 5)
    fun minute(c: Context) = p(c).getInt("minute", 30)
    fun setTime(c: Context, h: Int, m: Int) = p(c).edit().putInt("hour", h).putInt("minute", m).apply()
    fun enabled(c: Context) = p(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, on: Boolean) = p(c).edit().putBoolean("enabled", on).apply()
    /** Max unanswered ringing time. The app flags the call when exceeded; it never hangs up. */
    fun ringSeconds(c: Context) = p(c).getInt("ring", 45).coerceIn(RING_MIN, RING_MAX)
    fun setRingSeconds(c: Context, s: Int) = p(c).edit().putInt("ring", s.coerceIn(RING_MIN, RING_MAX)).apply()
    /** yyyy-MM-dd of the last daily run: the duplicate-call guard. */
    fun lastRun(c: Context): String = p(c).getString("lastRun", "") ?: ""
    fun setLastRun(c: Context, d: String) = p(c).edit().putString("lastRun", d).commit()
    /** When the pending alarm is meant to fire (0 = nothing scheduled). Used to reject very late firings. */
    fun scheduledAt(c: Context) = p(c).getLong("scheduledAt", 0L)
    fun setScheduledAt(c: Context, t: Long) = p(c).edit().putLong("scheduledAt", t).commit()
}
