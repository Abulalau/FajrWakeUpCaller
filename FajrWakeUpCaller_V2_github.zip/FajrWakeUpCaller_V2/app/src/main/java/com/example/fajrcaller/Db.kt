package com.example.fajrcaller

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Every status that can appear in call history. */
object St {
    const val ANSWERED = "ANSWERED"                       // call log shows connected time > 0
    const val NO_ANSWER = "NO_ANSWER"                     // call log shows 0 connected time
    const val CALL_ENDED = "CALL_ENDED"                   // call ended; answered/unanswered unknown
    const val FAILED_PERMISSION = "FAILED_PERMISSION"
    const val FAILED_NO_SIM = "FAILED_NO_SIM"
    const val FAILED_NO_NETWORK = "FAILED_NO_NETWORK"     // airplane mode / no cellular service
    const val FAILED_CALL = "FAILED_CALL"                 // dial error, call never started, or ended instantly
    const val FAILED_SERVICE = "FAILED_SERVICE"           // Android refused to start the service
    const val SKIPPED_DUPLICATE = "SKIPPED_DUPLICATE"
    const val SKIPPED_BUSY = "SKIPPED_BUSY"               // a sequence was already running
    const val SKIPPED_PHONE_BUSY = "SKIPPED_PHONE_BUSY"   // phone was already in another call
    const val SKIPPED_DISABLED = "SKIPPED_DISABLED"
    const val SKIPPED_TOO_LATE = "SKIPPED_TOO_LATE"
    const val NO_CONTACTS = "NO_CONTACTS"
    const val ABORTED_CALL_ACTIVE = "ABORTED_CALL_ACTIVE"
    const val ALARM_NOT_SCHEDULED = "ALARM_NOT_SCHEDULED"
    const val ERROR = "ERROR"
}

data class Contact(val id: Long, val name: String, val number: String, val enabled: Boolean)
data class LogRow(val ts: Long, val contact: String, val number: String, val status: String, val note: String)

class Db(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "fajr.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE contacts(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, number TEXT, enabled INTEGER DEFAULT 1)")
        db.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, contact TEXT, number TEXT, status TEXT, note TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun contacts(): List<Contact> {
        val out = ArrayList<Contact>()
        readableDatabase.rawQuery("SELECT id,name,number,enabled FROM contacts ORDER BY id", null).use {
            while (it.moveToNext()) out.add(Contact(it.getLong(0), it.getString(1), it.getString(2), it.getInt(3) == 1))
        }
        return out
    }
    fun addContact(name: String, number: String) {
        writableDatabase.insert("contacts", null, ContentValues().apply {
            put("name", name); put("number", number); put("enabled", 1)
        })
    }
    fun setEnabled(id: Long, on: Boolean) {
        writableDatabase.update("contacts", ContentValues().apply { put("enabled", if (on) 1 else 0) }, "id=?", arrayOf(id.toString()))
    }
    fun isEnabled(id: Long): Boolean {
        readableDatabase.rawQuery("SELECT enabled FROM contacts WHERE id=?", arrayOf(id.toString())).use {
            return it.moveToFirst() && it.getInt(0) == 1
        }
    }
    fun deleteContact(id: Long) { writableDatabase.delete("contacts", "id=?", arrayOf(id.toString())) }

    fun log(contact: String, number: String, status: String, note: String = "") {
        writableDatabase.insert("history", null, ContentValues().apply {
            put("ts", System.currentTimeMillis()); put("contact", contact)
            put("number", number); put("status", status); put("note", note)
        })
    }
    fun history(limit: Int = 300): List<LogRow> {
        val out = ArrayList<LogRow>()
        readableDatabase.rawQuery("SELECT ts,contact,number,status,note FROM history ORDER BY id DESC LIMIT $limit", null).use {
            while (it.moveToNext()) out.add(LogRow(it.getLong(0), it.getString(1), it.getString(2), it.getString(3), it.getString(4) ?: ""))
        }
        return out
    }
    fun clearHistory() { writableDatabase.delete("history", null, null) }
}
