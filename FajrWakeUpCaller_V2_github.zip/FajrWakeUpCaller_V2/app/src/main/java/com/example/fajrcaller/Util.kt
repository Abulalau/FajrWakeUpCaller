package com.example.fajrcaller

import android.os.Build
import android.view.View
import android.view.WindowInsets

/** Android 15 (targetSdk 35) forces edge-to-edge; keep content clear of system bars. */
fun applyInsets(v: View) {
    v.setOnApplyWindowInsetsListener { view, ins ->
        if (Build.VERSION.SDK_INT >= 30) {
            val b = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            view.setPadding(b.left, b.top, b.right, b.bottom)
        } else {
            @Suppress("DEPRECATION")
            view.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
        }
        ins
    }
}
