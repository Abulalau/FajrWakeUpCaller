package com.example.fajrcaller

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {
    private lateinit var db: Db
    private lateinit var root: LinearLayout
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = Db(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(24)) }
        val sv = ScrollView(this).apply { clipToPadding = false; addView(root) }
        applyInsets(sv)
        setContentView(sv)
    }

    override fun onResume() { super.onResume(); Scheduler.schedule(this); render() }

    private fun label(t: String, size: Float = 14f) = TextView(this).apply { text = t; textSize = size; setPadding(0, dp(4), 0, dp(4)) }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun missingRequired(): List<String> {
        val l = mutableListOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) { render() }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= 31)
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
    }

    private fun render() {
        root.removeAllViews()
        val h = Prefs.hour(this); val m = Prefs.minute(this)
        root.addView(label("Fajr Wake-Up Caller", 22f))

        // ---- exact alarm warning (hard requirement for the daily call)
        if (Prefs.enabled(this) && !Scheduler.canExact(this)) {
            root.addView(TextView(this).apply {
                text = "WARNING: THE DAILY CALL IS NOT SCHEDULED.\nThis app needs 'Alarms & reminders' access to run at the exact time. " +
                        "Tap the button below, switch it on for this app, then come back."
                setTextColor(Color.rgb(139, 0, 0)); setBackgroundColor(Color.rgb(255, 224, 224)); setPadding(dp(12), dp(12), dp(12), dp(12))
            })
            root.addView(btn("Grant exact alarm access") { openExactAlarmSettings() })
        }

        root.addView(Switch(this).apply {
            text = "Daily calls enabled"; isChecked = Prefs.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setEnabled(this@MainActivity, on); Scheduler.schedule(this@MainActivity); render() }
        })
        val nextTxt = when {
            !Prefs.enabled(this) -> "off"
            Prefs.scheduledAt(this) > 0 -> DateFormat.getDateTimeInstance().format(Date(Prefs.scheduledAt(this)))
            else -> "NOT SCHEDULED (see warning)"
        }
        root.addView(label("Next call: $nextTxt"))
        root.addView(btn("Call time: %02d:%02d  (tap to change)".format(h, m)) {
            TimePickerDialog(this, { _, hh, mm -> Prefs.setTime(this, hh, mm); Scheduler.schedule(this); render() }, h, m, true).show()
        })

        // ---- ring limit
        val ring = Prefs.ringSeconds(this)
        val ringLbl = label("")
        fun ringText(s: Int) = "Max unanswered ringing time: ${s}s. If a call is still active after this, history flags " +
                "'ring limit exceeded'. The app never hangs up; the carrier or the other person ends the call."
        ringLbl.text = ringText(ring)
        root.addView(ringLbl)
        root.addView(SeekBar(this).apply {
            max = Prefs.RING_MAX - Prefs.RING_MIN; progress = ring - Prefs.RING_MIN
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + Prefs.RING_MIN; Prefs.setRingSeconds(this@MainActivity, v); ringLbl.text = ringText(v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        // ---- setup
        root.addView(label("Setup", 18f))
        val miss = missingRequired()
        if (miss.isNotEmpty()) root.addView(btn("1. Grant phone & notification permissions") { requestPermissions(miss.toTypedArray(), 1) })
        else root.addView(label("Required permissions: OK"))
        root.addView(label(if (Scheduler.canExact(this)) "Exact alarms: OK" else "Exact alarms: NOT GRANTED"))
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            root.addView(btn("3. Disable battery optimization for this app") {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            })
        } else root.addView(label("Battery optimization: exempt (OK)"))
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            root.addView(btn("Optional: allow call-log access (shows answered / no answer)") {
                requestPermissions(arrayOf(Manifest.permission.READ_CALL_LOG), 2)
            })
        } else root.addView(label("Call-log access: OK (answered / no answer shown)"))

        // ---- contacts
        root.addView(label("Family contacts (called one by one, in this order)", 18f))
        val name = EditText(this).apply { hint = "Name" }
        val num = EditText(this).apply { hint = "Mobile number (e.g. +919876543210)"; inputType = InputType.TYPE_CLASS_PHONE }
        root.addView(name); root.addView(num)
        root.addView(btn("Add contact") {
            val n = name.text.toString().trim()
            val d = num.text.toString().replace(Regex("[\\s\\-()]"), "")
            if (n.isEmpty() || !Regex("^\\+?[0-9]{7,15}$").matches(d)) toast("Enter a name and a valid number")
            else { db.addContact(n, d); render() }
        })
        db.contacts().forEach { c ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(Switch(this).apply {
                text = "${c.name}\n${c.number}"; isChecked = c.enabled
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnCheckedChangeListener { _, on -> db.setEnabled(c.id, on) }
            })
            row.addView(btn("Test") {
                AlertDialog.Builder(this).setMessage("Place a real call to ${c.name} now?")
                    .setPositiveButton("Call") { _, _ ->
                        startForegroundService(Intent(this, CallService::class.java).putExtra("name", c.name).putExtra("number", c.number))
                        toast("Calling... see History for the result")
                    }.setNegativeButton("Cancel", null).show()
            })
            row.addView(btn("X") { db.deleteContact(c.id); render() })
            root.addView(row)
        }

        root.addView(btn("Call history") { startActivity(Intent(this, HistoryActivity::class.java)) })
    }
}
