package com.example.fajrcaller

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object Scheduler {
    const val ACTION = "com.example.fajrcaller.DAILY_CALL"

    enum class Result { SCHEDULED, DISABLED, NEEDS_EXACT_PERMISSION }

    fun nextTrigger(h: Int, m: Int): Long {
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    /** Android 12+ (API 31): exact alarms need the user to allow "Alarms & reminders". Earlier: always allowed. */
    fun canExact(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    private fun alarmPi(ctx: Context) = PendingIntent.getBroadcast(
        ctx, 1, Intent(ctx, AlarmReceiver::class.java).setAction(ACTION),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    /**
     * Cancels and re-arms the single daily alarm. Idempotent.
     * Without exact-alarm access NOTHING is scheduled: we do not pretend a different alarm type is a
     * permission-free substitute. The UI shows a warning and sends the user to the system setting.
     */
    fun schedule(ctx: Context): Result {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = alarmPi(ctx)
        am.cancel(pi)
        Prefs.setScheduledAt(ctx, 0L)
        if (!Prefs.enabled(ctx)) return Result.DISABLED
        if (!canExact(ctx)) return Result.NEEDS_EXACT_PERMISSION
        val t = nextTrigger(Prefs.hour(ctx), Prefs.minute(ctx))
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        Prefs.setScheduledAt(ctx, t)
        return Result.SCHEDULED
    }
}
