package com.example.fajrcaller

import android.app.Activity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        title = "Call history"
        val db = Db(this)
        val list = ListView(this)
        fun load() {
            val f = SimpleDateFormat("yyyy-MM-dd  HH:mm:ss", Locale.getDefault())
            val rows = db.history().map {
                val mark = when {
                    it.status == St.ANSWERED -> "[OK] "
                    it.status.startsWith("FAILED") || it.status.startsWith("ABORTED") || it.status == St.ALARM_NOT_SCHEDULED -> "[!] "
                    else -> ""
                }
                "${f.format(Date(it.ts))}\n${it.contact}  ${it.number}\n$mark${it.status}" + if (it.note.isNotEmpty()) " - ${it.note}" else ""
            }
            list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows.ifEmpty { listOf("No calls yet") })
        }
        val clear = Button(this).apply { text = "Clear history"; setOnClickListener { db.clearHistory(); load() } }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(clear); addView(list) }
        applyInsets(root)
        setContentView(root); load()
    }
}
