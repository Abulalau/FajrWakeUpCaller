@echo off
rem Minimal launcher with the same entry point as the standard Gradle wrapper script.
set APP_HOME=%~dp0
set JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
if not exist "%JAR%" (
  echo ERROR: %JAR% is missing.
  echo Fix: install Gradle once and run:  gradle wrapper --gradle-version 8.9
  echo or open this folder in Android Studio, which does not need the jar.
  exit /b 1
)
if defined JAVA_HOME (set JAVACMD=%JAVA_HOME%\bin\java.exe) else (set JAVACMD=java.exe)
"%JAVACMD%" -Xmx64m -Xms64m -Dorg.gradle.appname=gradlew -classpath "%JAR%" org.gradle.wrapper.GradleWrapperMain %*
