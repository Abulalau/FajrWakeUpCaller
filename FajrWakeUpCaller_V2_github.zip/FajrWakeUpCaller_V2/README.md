# Fajr Wake-Up Caller V2

Native Kotlin app, no dependencies, fully offline. Not compiled or run on a device by the author
of this package (no Android SDK was available): treat first build and first on-phone test as unverified.

## Build
1. Android Studio (free): open this folder, let Gradle sync (needs internet once to fetch Gradle 8.9,
   Android Gradle Plugin 8.7.3, Kotlin 2.0.21 and SDK 35 from Google/Maven). Build > Build APK(s).
2. Or terminal: `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`
   (needs the wrapper jar, see below).

### Gradle wrapper jar
`gradlew` and `gradlew.bat` are included. `gradle/wrapper/gradle-wrapper.jar` is NOT: it is a binary that
could not be created offline, and a fake would be worse than none. Get it with ONE of:
* open the project in Android Studio (it does not need the jar), or
* install Gradle (any recent version) and run `gradle wrapper --gradle-version 8.9` in this folder.

## Setup on the phone
1. Grant phone + notification permissions. 2. Allow "Alarms & reminders" (red banner tells you).
3. Disable battery optimization. 4. Optional: allow call-log access. 5. Add contacts, press Test.
Xiaomi/Oppo/Vivo/Samsung etc.: also enable Autostart / unrestricted background in vendor settings.

## Exact alarms
Android 12+ requires the user to allow exact alarms; Android 14+ has it off by default for new installs.
Without it the app schedules NOTHING, shows a red warning with a button to the system setting, and logs
ALARM_NOT_SCHEDULED after boot. Granting it triggers a system broadcast that re-arms the alarm.
(`setAlarmClock` is not used as a permission-free workaround.)

## Calling behavior and its Android limits
* Dialing uses `TelecomManager.placeCall` with CALL_PHONE on the default SIM.
* Contacts are dialed strictly one by one: next number only after call state is IDLE again.
* A normal app cannot tell "ringing" from "answered" while the call is live (that needs default-dialer /
  InCallService status or privileged precise-call-state APIs). So the app NEVER hangs up.
* "Max unanswered ringing time" (15-120 s, default 45): once exceeded while the call is still active, history
  records "ring limit exceeded", and the app keeps waiting. The carrier normally ends unanswered calls itself.
  A hard 20-minute safety cap aborts the rest of the sequence rather than overlap calls.
* After the call, with optional READ_CALL_LOG access, history says ANSWERED or NO_ANSWER (best effort,
  call-log duration semantics vary by phone maker). Without it: CALL_ENDED (unknown).
* A spoken message cannot be played into the call. Use a custom ringtone on the family members' phones.
* Reboot: unlock the phone once so credential-encrypted storage is available.
* Dual SIM: default calling SIM is used.

## Statuses
ANSWERED, NO_ANSWER, CALL_ENDED, FAILED_PERMISSION, FAILED_NO_SIM, FAILED_NO_NETWORK, FAILED_CALL,
FAILED_SERVICE, SKIPPED_DUPLICATE, SKIPPED_BUSY, SKIPPED_PHONE_BUSY, SKIPPED_DISABLED, SKIPPED_TOO_LATE,
NO_CONTACTS, ABORTED_CALL_ACTIVE, ALARM_NOT_SCHEDULED, ERROR.

## Service concurrency
One worker thread owns a sequence. Extra start requests re-enter foreground (required by Android), are
logged SKIPPED_BUSY and ignored; only the worker stops the service, via `stopSelf(lastStartId)` under a lock,
so a newer start is never killed by an older stop.

## Android version notes (from documentation, not device-tested)
| Android | What matters here |
|---|---|
| 12 (API 31) | Exact alarm needs user-granted access (`canScheduleExactAlarms`). Background FGS-start limits: starting from an exact-alarm broadcast is a documented exemption for apps holding exact-alarm access. READ_PHONE_STATE needed for call state. |
| 13 (API 33) | POST_NOTIFICATIONS runtime permission; the service still runs without it, but its notification is hidden. |
| 14 (API 34) | FGS type mandatory: `specialUse` + FOREGROUND_SERVICE_SPECIAL_USE. (`phoneCall` type would need MANAGE_OWN_CALLS, so it is not used.) Exact alarm denied by default. |
| 15 (API 35) | Edge-to-edge enforced (insets handled in `Util.kt`). New FGS-from-BOOT_COMPLETED limits do not apply: boot only re-arms the alarm, it never starts the service. FGS timeouts apply to dataSync/mediaProcessing only. |
